#!/usr/bin/env bash
# A realistic batch: several tools at once, one of them fat-fingered.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init mixed-batch

heading "13. Installing five things at once, one of them misspelled"
explain "The command people actually type: a handful of tools in one go, with a"
explain "typo in the middle of it."
explain ""
explain "Before: four trees printed to stdout, a WARN carrying the real reason, and"
explain "an error naming only the environment. The trees and the failure interleave"
explain "with no visual separation, and the misspelled one is easy to miss."
explain ""
explain "After: a block per environment in the order they finished, the broken one"
explain "marked in place so you can see where in the run it went wrong, and the"
explain "reason at the end, attributed."
explain ""
explain "Everything downloads from an empty cache, twice, so this is the slow one."

compare global install python brooooken git zed jj

heading "13b. What is on PATH afterwards"
explain "The four that worked really did install. Note how the header carries the"
explain "version for the single-package environments, and how python's eleven"
explain "executables get a line each while the shorter lists stay on one."

compare global list
finish
