#!/usr/bin/env bash
# The state view.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init list

heading "3. Listing global environments"
explain "Before, list drew a tree headed by the full path of the manifest, which"
explain "wraps mid-path on a normal terminal. After, the header is gone and the"
explain "rows hang off their own environment, so each block stands on its own."
explain ""
explain "Watch the row labels: they are the keys of pixi-global.toml, so the output"
explain "tells you what to edit."

prepare global install ripgrep
prepare global install --environment demo --with fd bat

compare global list
finish
