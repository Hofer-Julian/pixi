#!/usr/bin/env bash
# Installing something that is already there.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init install-again

heading "2. Installing a tool that is already installed"
explain "You named the environment, so you get an answer about it either way."
explain "Before it was a tree annotated '(already installed)'. After it is a single"
explain "line, and the word matches the one every other command uses."

prepare global install ripgrep

compare global install ripgrep
finish
