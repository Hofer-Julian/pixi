#!/usr/bin/env bash
# The two knobs.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init verbosity

heading "9. --quiet"
explain "Before, --quiet set the log level to off but left the report untouched,"
explain "because the report was written with eprintln! rather than tracing. After,"
explain "it silences the report."

compare global install --quiet ripgrep

heading "9b. --quiet still shows failures"
explain "Silent when it works, not when it does not."

compare global install --quiet definitely-not-a-real-package-xyz

heading "9c. --verbose"
explain "The transitive count expands into a row per package. Before there was no"
explain "such thing: packages that came along with the one you asked for were"
explain "invisible unless you went looking in 'pixi global list'."
explain ""
explain "Note that -v also raises the log level, so you get INFO lines with it."

compare global install --verbose --force-reinstall ripgrep
finish
