#!/usr/bin/env bash
# Every demo in order, stopping between them.
set -uo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
source ./common.sh

# Fail once, up front, rather than in all twelve demos.
require_binaries

scripts=()
for candidate in [0-9][0-9]-*.sh; do
    [ "$candidate" = "$(basename "${BASH_SOURCE[0]}")" ] && continue
    scripts+=("$candidate")
done
total=${#scripts[@]}

for index in "${!scripts[@]}"; do
    script="${scripts[$index]}"
    printf '\n%s%s%s\n' "$DIM" "======================================================================" "$RESET"
    printf '%s%s  (%d of %d)%s\n' "$BOLD" "$script" "$((index + 1))" "$total" "$RESET"
    printf '%s%s%s\n' "$DIM" "======================================================================" "$RESET"
    "./$script"

    if [ "$((index + 1))" -lt "$total" ]; then
        printf '\n%sNext: %s%s' "$DIM" "${scripts[$((index + 1))]}" "$RESET"
        pause
    fi
done

printf '\n%sThat was all of them.%s\n' "$DIM" "$RESET"
