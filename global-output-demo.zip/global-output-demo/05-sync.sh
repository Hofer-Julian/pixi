#!/usr/bin/env bash
# Several environments at once, which is where the layout had to stream.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init sync

heading "5. Syncing several environments"
explain "This one takes a moment to set up: three tools are installed into both"
explain "homes, then their exposed binaries are deleted so sync has work to do."
explain ""
explain "Before: two lines per environment, and an environment exposing nine"
explain "executables printed each on its own line under a sentence."
explain ""
explain "After: a block per environment, streamed as each one finishes. The rows"
explain "hang off their own header rather than off one trunk for the whole run,"
explain "which is what lets a block be printed the moment its environment is done."

prepare global install bat fd ripgrep
find "$BEFORE_HOME/bin" -maxdepth 1 -type f -delete 2>/dev/null
find "$AFTER_HOME/bin" -maxdepth 1 -type f -delete 2>/dev/null

compare global sync

heading "5b. Syncing when there is nothing to do"
explain "Before: a fixed sentence. After: a count, so a sync over twenty"
explain "environments does not print twenty lines saying nothing happened."

compare global sync
finish
