#!/usr/bin/env bash
# Taking things away.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init remove-uninstall

heading "6. Removing a package from an environment"
explain "Before, several changes to one environment became several unrelated"
explain "sentences, each repeating the environment name. After, they are rows of one"
explain "block, and the marker says what happened to each item."

prepare global install --environment demo --with fd bat

compare global remove --environment demo fd

heading "6b. Uninstalling an environment"

compare global uninstall demo
finish
