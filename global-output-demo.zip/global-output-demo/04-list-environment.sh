#!/usr/bin/env bash
# One environment in detail.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init list-environment

heading "4. Listing one environment"
explain "Before: a sentence, then the package table, then a footer in a third"
explain "format. On a 140 package environment the summary scrolls away before you"
explain "can read it."
explain ""
explain "After: the block first, including everything the environment pulled in and"
explain "its total size, then the same table."

prepare global install --environment demo --with fd bat

compare global list --environment demo
finish
