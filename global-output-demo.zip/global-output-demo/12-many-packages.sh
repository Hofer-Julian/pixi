#!/usr/bin/env bash
# An environment holding a lot of packages.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init many-packages

heading "12. An environment with many packages"
explain "IPython pulls in around forty packages you did not ask for. Before, they"
explain "were invisible: the install output named only what you requested, and"
explain "nothing told you the environment had grown."
explain ""
explain "After, they are one summary row. Watch the progress bars while it works,"
explain "since the cache is empty."

compare global install ipython

heading "12b. The same install with --verbose"
explain "The count expands into a row per package. Before there was no equivalent"
explain "at all. Note that -v also raises the log level, so log lines come with it."

compare global install --verbose --force-reinstall ipython

heading "12c. Listing the environment"
explain "Before: a sentence, then forty rows of table, then a footer in a third"
explain "format that has scrolled off by the time you get there."
explain ""
explain "After: the block first, with the package count and the total size, then the"
explain "same table."

compare global list --environment ipython
finish
