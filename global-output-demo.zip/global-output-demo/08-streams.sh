#!/usr/bin/env bash
# Which stream carries what.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init streams

heading "8. stdout and stderr"
explain "Before, install wrote its tree to stdout while remove, update and sync"
explain "wrote to stderr. Two commands in the same subcommand, two streams."
explain ""
explain "After: every change report is status and goes to stderr; list is data and"
explain "goes to stdout. Below, stdout is redirected to a file and only stderr"
explain "reaches the screen."

show_command "global install ripgrep > out.txt"
pause

side "BEFORE  ($BEFORE_VERSION)"
pixi_before global install ripgrep >"$DEMO_TMP/before-out.txt"
printf '\n%sstdout captured in out.txt:%s\n' "$BOLD" "$RESET"
cat "$DEMO_TMP/before-out.txt"
pause

side "AFTER   (this branch)"
pixi_after global install ripgrep >"$DEMO_TMP/after-out.txt"
printf '\n%sstdout captured in out.txt:%s\n' "$BOLD" "$RESET"
cat "$DEMO_TMP/after-out.txt"
printf '%s(empty: the report stayed on stderr, where you could still read it)%s\n' "$DIM" "$RESET"
pause

heading "8b. list is data, so it keeps stdout"
show_command "global list > out.txt"
pause

side "AFTER   (this branch)"
pixi_after global list >"$DEMO_TMP/after-list.txt"
printf '\n%sstdout captured in out.txt:%s\n' "$BOLD" "$RESET"
cat "$DEMO_TMP/after-list.txt"
finish
