#!/usr/bin/env bash
# A lot of environments at once.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init many-environments

heading "11. Many environments"
explain "Five tools are installed into both homes from an empty cache, so this part"
explain "takes a while. Then their exposed binaries are deleted, so the sync that"
explain "follows has real work to do in every one of them."

prepare global install bat fd ripgrep tealdeer zoxide

heading "11a. Listing them"
explain "Before: a tree headed by the full manifest path. After: a block each,"
explain "separated by a blank line, so the eye can find the environment it wants."

compare global list

find "$BEFORE_HOME/bin" -maxdepth 1 -type f -delete 2>/dev/null
find "$AFTER_HOME/bin" -maxdepth 1 -type f -delete 2>/dev/null

heading "11b. Syncing them"
explain "Before: two lines per environment, ten lines of checkmarks with the"
explain "environment name repeated on each. After: a block each, streamed as they"
explain "finish."

compare global sync

heading "11c. Syncing again, with nothing to do"
explain "Before: one fixed sentence. After: a single count. The difference grows"
explain "with the number of environments, which is the point."

compare global sync
finish
