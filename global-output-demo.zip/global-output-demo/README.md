# `pixi global` output demos

Side by side runs of the same command against the released pixi and the one
built from this branch, so you can see what the output rework actually changed.

## Running

Build the branch first:

```bash
cargo build --workspace
```

Then run one demo, or all of them:

```bash
./global-output-demo/01-install.sh
./global-output-demo/00-run-all.sh
```

Each script prints what it is about, shows the command, and waits for a
keystroke before running it. Then it runs the same command with the released
pixi, waits again, and runs it with the new one. `00-run-all.sh` stops between
demos too, so you can leave it going and read at your own pace.

## Safety and speed

Every demo gets its own throwaway `PIXI_HOME` **and its own package cache**
under `$TMPDIR/pixi-global-demo/`, wiped at the start of each run. Your own
global installation and package cache are never read or written.

The cost of that is time: both sides download everything from scratch, so a
demo that installs Python or IPython takes a few minutes. It is deliberate.
A warm cache skips the downloads, and the progress display is half of what
there is to look at. `11` and `12` are the slow ones.

## The binaries

`before` is whatever `pixi` resolves to on `PATH`, `after` is
`target/pixi/debug/pixi`. Override either:

```bash
PIXI_BEFORE=/path/to/old/pixi PIXI_AFTER=/path/to/new/pixi ./01-install.sh
```

## The demos

| Script | What it shows |
| --- | --- |
| `01-install.sh` | A first install. Install used to print a tree and discard the changes it had computed. |
| `02-install-again.sh` | The no-op case. An environment you named always gets an answer. |
| `03-list.sh` | `list` in the same shape as the reports, without the wrapping manifest path. |
| `04-list-environment.sh` | One environment: the summary above the package table instead of below it. |
| `05-sync.sh` | Several environments, streamed as they finish, and the no-op count. |
| `06-remove-uninstall.sh` | Removals, and several changes to one environment in one block. |
| `07-failure.sh` | The failure path, the `No global environments found.` that used to precede the error, and `update` carrying on past a failure. |
| `08-streams.sh` | Which stream carries what, with stdout redirected to a file. |
| `09-verbosity.sh` | `--quiet` silencing the report, `--verbose` expanding transitive packages. |
| `10-many-exposed.sh` | Python, which exposes eleven executables on one unreadable line. |
| `11-many-environments.sh` | Five environments listed, synced, and synced again with nothing to do. |
| `12-many-packages.sh` | IPython and the forty packages that come with it, summarised, expanded under `-v`, and totalled in `list`. |
| `13-mixed-batch.sh` | `pixi global install python brooooken git zed jj`: five at once, one misspelled. The slowest one. |
