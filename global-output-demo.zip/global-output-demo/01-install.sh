#!/usr/bin/env bash
# A first install: the command that changed the most.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init install

heading "1. Installing a tool"
explain "Before, install printed an ASCII tree of the resulting state, and threw"
explain "away the list of changes it had already computed. After, it reports what"
explain "it did: which dependency was added, how many packages came along with it,"
explain "which executables and completions are now exposed."

compare global install ripgrep
finish
