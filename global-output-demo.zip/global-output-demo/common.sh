#!/usr/bin/env bash
# Shared helpers for the `pixi global` output demos.
#
# Every demo runs the same command twice against throwaway `PIXI_HOME`
# directories: once with the released pixi, once with the one built from this
# branch. Your own global installation is never touched.

set -uo pipefail

DEMO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$DEMO_ROOT/.." && pwd)"

# The released pixi on `PATH` stands in for "before"; override either with an
# environment variable if you want a different pair.
PIXI_BEFORE="${PIXI_BEFORE:-$(command -v pixi || true)}"
PIXI_AFTER="${PIXI_AFTER:-$REPO_ROOT/target/pixi/debug/pixi}"

if [ -t 1 ]; then
    BOLD=$'\033[1m'
    DIM=$'\033[2m'
    CYAN=$'\033[36m'
    RESET=$'\033[0m'
else
    BOLD=''
    DIM=''
    CYAN=''
    RESET=''
fi

# Chrome around the pixi output, kept visually distinct from what pixi prints.
rule() {
    printf '%s%s%s\n' "$DIM" "----------------------------------------------------------------------" "$RESET"
}

heading() {
    printf '\n%s%s%s\n' "$BOLD$CYAN" "$1" "$RESET"
}

explain() {
    printf '%s%s%s\n' "$DIM" "$1" "$RESET"
}

pause() {
    if [ -t 0 ]; then
        printf '\n%s[press any key]%s' "$DIM" "$RESET"
        read -rsn1
        printf '\r%s\r' "                "
    fi
}

require_binaries() {
    if [ -z "$PIXI_BEFORE" ] || [ ! -x "$PIXI_BEFORE" ]; then
        printf 'No released pixi found on PATH. Set PIXI_BEFORE to one.\n' >&2
        exit 1
    fi
    if [ ! -x "$PIXI_AFTER" ]; then
        printf 'No pixi built from this branch at %s.\n' "$PIXI_AFTER" >&2
        printf 'Build it with `cargo build --workspace`, or set PIXI_AFTER.\n' >&2
        exit 1
    fi
}

# Fresh, isolated homes and package caches for this demo. Everything is wiped
# on every run, so the demos are reproducible in any order and both sides start
# equally cold: a warm cache on the second run would skip the downloads and
# hide half of what there is to see.
demo_init() {
    require_binaries
    local name="$1"
    DEMO_TMP="${TMPDIR:-/tmp}/pixi-global-demo/$name"
    BEFORE_HOME="$DEMO_TMP/before"
    AFTER_HOME="$DEMO_TMP/after"
    BEFORE_CACHE="$DEMO_TMP/before-cache"
    AFTER_CACHE="$DEMO_TMP/after-cache"
    rm -rf "$DEMO_TMP"
    mkdir -p "$BEFORE_HOME" "$AFTER_HOME" "$BEFORE_CACHE" "$AFTER_CACHE"
    BEFORE_VERSION="$("$PIXI_BEFORE" --version 2>/dev/null | head -1)"
}

pixi_before() {
    env PIXI_HOME="$BEFORE_HOME" PIXI_CACHE_DIR="$BEFORE_CACHE" "$PIXI_BEFORE" "$@"
}

pixi_after() {
    env PIXI_HOME="$AFTER_HOME" PIXI_CACHE_DIR="$AFTER_CACHE" "$PIXI_AFTER" "$@"
}

# Bring both homes into the same starting state, without showing the output.
prepare() {
    printf '%s(preparing: pixi %s)%s\n' "$DIM" "$*" "$RESET"
    pixi_before "$@" >/dev/null 2>&1
    pixi_after "$@" >/dev/null 2>&1
}

show_command() {
    printf '\n%sCommand%s\n' "$BOLD" "$RESET"
    printf '  pixi %s\n' "$*"
}

side() {
    printf '\n%s%s%s\n' "$BOLD" "$1" "$RESET"
    rule
}

# The whole point: same command, both binaries, one keystroke apart.
compare() {
    show_command "$@"
    pause

    side "BEFORE  ($BEFORE_VERSION)"
    pixi_before "$@"
    printf '%s(exit code %d)%s\n' "$DIM" "$?" "$RESET"
    pause

    side "AFTER   (this branch)"
    pixi_after "$@"
    printf '%s(exit code %d)%s\n' "$DIM" "$?" "$RESET"
    printf '\n'
}

finish() {
    printf '\n%sEnd of demo.%s\n' "$DIM" "$RESET"
}
