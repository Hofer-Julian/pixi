#!/usr/bin/env bash
# An environment that exposes a lot of executables.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init many-exposed

heading "10. An environment exposing many executables"
explain "Python exposes eleven: idle3, pydoc, python, python3-config and friends."
explain ""
explain "Before, they were comma-joined onto a single tree line that runs well past"
explain "any terminal width and wraps wherever the terminal happens to break it,"
explain "losing the indentation."
explain ""
explain "After, a list of five or more gets one item per line, aligned under the"
explain "value column. Four or fewer stay on one wrapped line, so the common case"
explain "does not get taller."
explain ""
explain "Nothing is cached yet, so this downloads Python first."

compare global install python

heading "10b. The same environment in list"

compare global list
finish
