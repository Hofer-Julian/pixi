#!/usr/bin/env bash
# What a failure looks like.
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"
demo_init failure

heading "7. A package that cannot be resolved"
explain "Before, three things went wrong at once: 'No global environments found.'"
explain "was printed before the error, because install listed the environments"
explain "unconditionally even after failing; the real diagnostic went through"
explain "tracing::warn!, which --quiet would have swallowed; and the failure was"
explain "stated twice, once with the reason and once with only the name."
explain ""
explain "After: the failed environment is marked where it happened, so you can see"
explain "where in the run it went wrong, and the reason waits until the end where"
explain "it does not interrupt the report."

compare global install definitely-not-a-real-package-xyz

heading "7b. One good package and one bad one"
explain "Execution continued past a failure before this change too. What is new is"
explain "that you can see where in the run it happened."

compare global install bat definitely-not-a-real-package-xyz

heading "7c. Update, where a failure used to stop the run"
explain "Before, one bad environment aborted the whole update and the ones after"
explain "it were never touched. After, each is reported where it happened and the"
explain "run carries on, like install and sync always did."

compare global update does-not-exist bat
finish
